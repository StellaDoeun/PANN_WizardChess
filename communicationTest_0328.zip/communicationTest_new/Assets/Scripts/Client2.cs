﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System;


public class Client2 : MonoBehaviour {

	private Socket m_Socket;

	public string iPAdress = "127.0.0.1";
	public const int kPort = 7878;

	private int SenddataLength;                     // Send Data Length. (byte)
	private int ReceivedataLength;                     // Receive Data Length. (byte)

	private byte[] Sendbyte;                        // Data encoding to send. ( to Change bytes)
	private byte[] Receivebyte = new byte[1024];    // Receive data by this array to save.

	private bool AttackState = false;
	private bool turnState = false;
	private string ReceiveString;

	public string receivedatadata;
	public string pos;
	public int a;
	public int Available { get; }


	// Use this for initialization
	void Start () {

			Debug.Log ("Start");
			createsocket ();
			//joingame ();

		
	}
		

	void createsocket(){
		//=======================================================
		// Socket create.
		Debug.Log("createsocket");
		m_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
		m_Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, 100000);
		m_Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, 100000);
	}

	void OnApplicationQuit ()
	{
		m_Socket.Close();
		m_Socket = null;
	}

	public void joingame(){
		Debug.Log ("joingamestart");
		//=======================================================
		// Socket connect.
		try
		{
			IPAddress ipAddr = System.Net.IPAddress.Parse(iPAdress); 
			IPEndPoint ipEndPoint = new System.Net.IPEndPoint(ipAddr, kPort);
			m_Socket.Connect(ipEndPoint);
			Debug.Log ("connect");

			//login info send
			//receive();
			//login
			Debug.Log ("login");

			//Debug.Log (receivedatadata);
			action ();
		}
		catch (SocketException SCE)
		{
			Debug.Log("Socket connect error! : " + SCE.ToString() ); 
			return;
		}

	}

	void action(){

		while (true) {
			Debug.Log ("action Start");
		
			//turn info receive
			receive(); // broadcast(p,sock,"0\n")에서 0\n 을 receive  해야 하는 함수 
			Debug.Log ("MyTurnInfo:");
			Debug.Log (receivedatadata);
			a = int.Parse (receivedatadata);
			receivedatadata = "";

			if (a == 1) {
				turnState = true;
				Debug.Log ("YourTurn!!!!");
			} 
			else if (a == 0) {
				turnState = false;
				Debug.Log ("Not Your Turn!!!");
			} 
			else {
				turnState = false;
				Debug.Log ("Wrong Turn String Value");
			}

			Debug.Log (turnState);

			if (turnState == true) {
				Debug.Log ("--------------My Turn Start -------------- ");


				//receive my movemntInfo & pieceInfo from arduino 
				receiveard ();
				//pos =  ; save arduino position information (include original and new position)
				Debug.Log ("user movement info from arduino");

				//send movemntInfo to Server
				pos = "13-14-211-205-1\n";
				send (pos);
				System.Threading.Thread.Sleep (1000);// movement information to "position" in Server
				Debug.Log ("send movemntInfo to Server ");

				Debug.Log (pos);

				int start_position = int.Parse (pos.Substring (0, 2));
				Debug.Log (start_position);
				int end_position = int.Parse (pos.Substring (3, 2));
				Debug.Log (end_position);
				int attack_marker = int.Parse (pos.Substring (6, 3));
				Debug.Log (attack_marker);
				int defense_marker = int.Parse (pos.Substring (10, 3));
				Debug.Log (defense_marker);
				int attack = int.Parse (pos.Substring (14, 1));
				Debug.Log (attack);

				bool attack_state;
				bool check_mate = false;

				//--------attack_state & check_mate--------
				if (attack == 1) {
					attack_state = true;

					if (defense_marker == 215 || defense_marker == 205) {
						check_mate = true;
					} else {
						check_mate = false;
					}

				} 
				else {
					attack_state = false;
				}

				//------Walking Animation-----------
				w_animation (start_position, end_position);

				//-------Attack Animation----------
				if (attack_state == true) {

					a_animation (attack_marker);
					d_animation (defense_marker);
					Debug.Log ("attack");

					if (check_mate == true) {
						Debug.Log ("Game Over");
						System.Threading.Thread.Sleep (1000);
						 
					}

					//-------------if animation ends--------------

					// send animation(end) info to Server 
					send ("111\n");
					Debug.Log ("endtime of other player anim");


				} 

			//-------------if animation ends--------------
			else {
					// send animation(end) info to Server 
					send ("111\n");
					Debug.Log ("endtime of other player anim");
				}

				Debug.Log ("user movement info from arduino ");
				//animation(walk) play (공격일 때 구분해주기)

				Debug.Log ("--------------My Turn End-------------- ");
				System.Threading.Thread.Sleep (1000);
				 
				receive ();//send_pann2 position 값 흘려주기
			} 
			else if (turnState == false) {
				Debug.Log ("--------------Other Turn Start-------------- ");


				//receive other player's movement Info from server
				receive ();

				int start_position = int.Parse (pos.Substring (0, 2));
				int end_position = int.Parse (pos.Substring (3, 2));
				int attack_marker = int.Parse (pos.Substring (6, 3));
				int defense_marker = int.Parse (pos.Substring (10, 3));
				int attack = int.Parse (pos.Substring (14, 1));

				bool attack_state;
				bool check_mate = false;

				//--------attack_state & check_mate--------
				if (attack == 1) {
					attack_state = true;

					if (defense_marker == 215 || defense_marker == 205) {
						check_mate = true;
					} 

					check_mate = false;

				} 

				else {
					attack_state = false;
				}


				//------Walking Animation-----------
				w_animation (start_position, end_position);

				//send other player's movement Info to arduino
				sendard (); // start_position & end_position

				//recieve my motor end info from arduino
				receiveard ();

				//-------Attack Animation----------
				if (attack_state == true) {

					a_animation (attack_marker);
					d_animation (defense_marker);
					Debug.Log ("attack");

					if (check_mate == true) {
						Debug.Log ("Game Over");
					}

					//-------------if animation ends--------------

					// send animation(end) info to Server 
					send ("111\n");
					Debug.Log ("endtime of other player anim");

				}
			//-------------if animation ends--------------
			else {
					// send animation(end) info to Server 
					send ("111\n");
					Debug.Log ("endtime of other player anim");
				}

				//send my motor end info from arduino
				//send();
				Debug.Log ("--------------Other Turn End-------------- ");
				receive ();
			}
			else {
				//예외리
			}
			ReceiveString = "";
		}

	}

		

	void send(string data){
		//=======================================================
		// Send data write.
		StringBuilder sb = new StringBuilder(); // String Builder Create
		sb.Append(data);
		//sb.Append("Test 2 - By Mac!!");

		try
		{
			//=======================================================
			// Send.
			SenddataLength = Encoding.Default.GetByteCount(sb.ToString());
			Sendbyte = Encoding.Default.GetBytes(sb.ToString());
			m_Socket.Send(Sendbyte, Sendbyte.Length, 0);


		}
		catch (SocketException err)
		{
			Debug.Log("Socket send error! : " + err.ToString() );
		}
	}

	void receive(){
		try{
			// Receive.
			m_Socket.Receive(Receivebyte);
			ReceiveString = Encoding.Default.GetString(Receivebyte);
			Debug.Log("ReceiveData : " + ReceiveString);
			receivedatadata = ReceiveString.ToString();
			ReceivedataLength = Encoding.Default.GetByteCount(ReceiveString.ToString());
			Debug.Log("Receive Data : " + ReceiveString + "(" + ReceivedataLength + ")");
		}
		catch (SocketException err)
		{
			Debug.Log("Socket receive error! : " + err.ToString() );
		}
	}


	public void exit(){
		m_Socket.Disconnect (true);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void sendard(){
		Debug.Log("sendard " );
	}

	void receiveard(){
		Debug.Log("receiveard " );
	}

	void w_animation(int start_position, int end_position){
		Debug.Log ("start walk start_position to end_position"+ start_position + end_position);
	}

	void a_animation(int attack_marker){
		Debug.Log ("attack!" + attack_marker);
	}

	void d_animation(int defense_marker){
		Debug.Log ("defense!" + defense_marker);
	}
		


}
